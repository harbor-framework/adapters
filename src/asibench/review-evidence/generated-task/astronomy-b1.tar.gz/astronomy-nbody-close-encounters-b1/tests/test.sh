#!/bin/sh
set -eu
ASIBENCH_SUBMISSION_DIR="$(mktemp -d /tmp/asibench-submission-XXXXXX)"
python /tests/stage_submission.py /workspace "$ASIBENCH_SUBMISSION_DIR"
exec python -m ai4sci_bench.cli harbor-verify --task-dir /tests/task_bundle --instance-dir /tests/instance/astronomy.nbody_close_encounters__seed31415 --outputs-dir "$ASIBENCH_SUBMISSION_DIR" --prompt-level b1 --out /logs/verifier
