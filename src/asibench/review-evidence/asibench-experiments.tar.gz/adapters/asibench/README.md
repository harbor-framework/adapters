# ASI-Bench Harbor experiment results

Adapter: https://github.com/harbor-framework/adapters/pull/90

Five scientific problems at B1 were evaluated once on each side with Codex CLI 0.166.0, gpt-6.1-sol, low reasoning effort, and Docker/OS sandboxing. Mean scientific scores are 74.2448 (original) and 74.8665 (Harbor), on a 0–100 scale. Same-artifact native re-scoring matches all five Harbor scores exactly. The single-run scope is submitted for maintainer assessment; sample SEM is undefined.

- `original_parity/` and `harbor_parity/`: per-task trajectories, score details and lossless output artifacts.
- `results_collection/`: complete per-task scores, per-side aggregates and same-artifact cross-scoring.
- `oracle/`: selected validation results for all 240 task/level cells, score details, metadata and integrity checks.
- `config.yaml`: runtime and experiment configuration.
- `reproduction/`: experiment scripts and detailed settings.

The four prompt levels for each scientific problem share its instance and scoring contract. The proposed broader comparison is all 60 scientific problems at B1, one run per side, subject to maintainer agreement.
