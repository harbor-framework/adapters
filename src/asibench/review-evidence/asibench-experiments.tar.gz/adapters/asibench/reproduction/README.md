# Reproduction

These scripts preserve the settings and orchestration of the completed five-problem B1 comparison. Run them from the ASI-Bench adapter artifact/source checkout with the corresponding frozen inputs and environments; their original repository-relative paths are retained.

See the adapter's full commands and runtime audit:
https://github.com/panjose/adapters/tree/5e69b9a8dffb4be0bc6b7fd793a7105a1f93a58b/src/asibench/parity

The adjacent config.yaml, original_parity/, harbor_parity/ and results_collection/ folders contain the portable experiment settings and evidence. Supply credentials through environment variables. No new experiments are required to inspect these files.
